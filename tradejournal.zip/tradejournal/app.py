"""Trade journal + rule-checking mentor bot. Run: python app.py  ->  http://localhost:5000"""
import csv, io, json, os, random, sqlite3, urllib.request
from datetime import datetime, timedelta
from flask import Flask, jsonify, request, send_from_directory

app = Flask(__name__, static_folder="static")
DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "journal.db")
RULES = {"max_trades_per_day": 5, "max_daily_loss": 500, "max_loss_per_trade": 200,
         "require_stop": 1, "cooldown_minutes": 10, "max_qty": 5}
COLS = ["symbol", "side", "qty", "entry", "exit", "stop", "opened", "closed", "pnl", "notes"]


def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    c.executescript("""CREATE TABLE IF NOT EXISTS trades(id INTEGER PRIMARY KEY, symbol TEXT, side TEXT,
        qty REAL, entry REAL, exit REAL, stop REAL, opened TEXT, closed TEXT, pnl REAL, notes TEXT);
        CREATE TABLE IF NOT EXISTS rules(k TEXT PRIMARY KEY, v REAL);""")
    return c


def get_rules():
    with db() as c:
        r = dict(RULES)
        r.update({x["k"]: x["v"] for x in c.execute("SELECT * FROM rules")})
        return r


def get_trades():
    with db() as c:
        return [dict(r) for r in c.execute("SELECT * FROM trades ORDER BY closed")]


def num(v):
    return None if v in (None, "") else float(v)


def insert(c, t):
    side = str(t.get("side", "long")).lower()
    entry, exit_, qty = num(t["entry"]), num(t["exit"]), num(t["qty"])
    pnl = num(t.get("pnl"))
    if pnl is None:
        d = (exit_ - entry) * qty
        pnl = d if side == "long" else -d
    opened = str(t["opened"]).replace(" ", "T")[:16]
    closed = str(t.get("closed") or t["opened"]).replace(" ", "T")[:16]
    c.execute("INSERT INTO trades(symbol,side,qty,entry,exit,stop,opened,closed,pnl,notes) VALUES(?,?,?,?,?,?,?,?,?,?)",
              (str(t["symbol"]).upper(), side, qty, entry, exit_, num(t.get("stop")), opened, closed,
               round(pnl, 2), t.get("notes", "")))


def stats(ts):
    wins = [t["pnl"] for t in ts if t["pnl"] > 0]
    losses = [t["pnl"] for t in ts if t["pnl"] < 0]
    gp, gl = sum(wins), -sum(losses)
    daily, cum, peak, curve, dd = {}, 0, 0, [], []
    for t in ts:
        d = t["closed"][:10]
        daily[d] = round(daily.get(d, 0) + t["pnl"], 2)
        cum += t["pnl"]
        peak = max(peak, cum)
        curve.append({"t": t["closed"], "v": round(cum, 2)})
        dd.append({"t": t["closed"], "v": round(cum - peak, 2)})
    days = list(daily.values())
    return {"count": len(ts), "wins": len(wins), "losses": len(losses),
            "profit_factor": round(gp / gl, 2) if gl else (round(gp, 2) if gp else 0),
            "win_rate": round(100 * len(wins) / len(ts), 1) if ts else 0,
            "day_wins": sum(d > 0 for d in days), "day_losses": sum(d < 0 for d in days),
            "day_win_pct": round(100 * sum(d > 0 for d in days) / len(days), 1) if days else 0,
            "avg_win": round(gp / len(wins), 2) if wins else 0,
            "avg_loss": round(-gl / len(losses), 2) if losses else 0,
            "total": round(sum(t["pnl"] for t in ts), 2), "daily": daily, "curve": curve, "drawdown": dd,
            "max_drawdown": min([x["v"] for x in dd], default=0),
            "best": max(ts, key=lambda t: t["pnl"]) if ts else None,
            "worst": min(ts, key=lambda t: t["pnl"]) if ts else None}


def mentor(ts, r, ai=True):
    """Check every trade against the user's rules and suggest improvements."""
    v = []  # violations
    def add(t, rule, msg):
        v.append({"id": t["id"], "rule": rule, "date": t["opened"][:10], "symbol": t["symbol"], "msg": msg})
    by_day = {}
    for t in sorted(ts, key=lambda t: t["opened"]):
        by_day.setdefault(t["opened"][:10], []).append(t)
    for day, trades in by_day.items():
        running, prev = 0, None
        for i, t in enumerate(trades):
            if i >= r["max_trades_per_day"]:
                add(t, "max_trades_per_day", f"Trade #{i+1} of the day; your limit is {int(r['max_trades_per_day'])}.")
            if running <= -r["max_daily_loss"]:
                add(t, "max_daily_loss", f"Opened after the day was already down ${-running:.0f} (limit ${r['max_daily_loss']:.0f}).")
            if prev and prev["pnl"] < 0:
                gap = (datetime.fromisoformat(t["opened"]) - datetime.fromisoformat(prev["closed"])).total_seconds() / 60
                if gap < r["cooldown_minutes"]:
                    add(t, "cooldown_minutes", f"Re-entered {gap:.0f} min after a loss (cooldown {int(r['cooldown_minutes'])} min). Possible revenge trade.")
            running += t["pnl"]
            prev = t
    for t in ts:
        if t["pnl"] < -r["max_loss_per_trade"]:
            add(t, "max_loss_per_trade", f"Lost ${-t['pnl']:.0f}; per-trade limit is ${r['max_loss_per_trade']:.0f}.")
        if r["require_stop"] and not t["stop"]:
            add(t, "require_stop", "No stop loss recorded.")
        elif t["stop"]:
            risk = abs(t["entry"] - t["stop"]) * t["qty"]
            if risk and t["pnl"] < -1.25 * risk:
                add(t, "stop_not_honored", f"Lost ${-t['pnl']:.0f} against planned risk of ${risk:.0f}. Stop was moved or ignored.")
        if t["qty"] > r["max_qty"]:
            add(t, "max_qty", f"Size {t['qty']:g} exceeds your max of {r['max_qty']:g}.")
    s = stats(ts)
    broken = {x["id"] for x in v}
    tips = []
    if not ts:
        return {"score": None, "violations": [], "tips": ["Add or import some trades first."], "stats": s}
    if s["avg_loss"] and s["avg_win"] and s["avg_loss"] > s["avg_win"] and s["win_rate"] < 60:
        tips.append(f"Your average loss (${s['avg_loss']:.0f}) is bigger than your average win (${s['avg_win']:.0f}). Cut losers faster or hold winners longer.")
    if s["win_rate"] < 40:
        tips.append(f"Win rate is {s['win_rate']}%. Fine only if winners are 2x+ your losers; otherwise tighten your setup criteria.")
    if len(broken) / len(ts) > 0.25:
        top = max({x["rule"] for x in v}, key=lambda k: sum(x["rule"] == k for x in v))
        tips.append(f"{len(broken)} of {len(ts)} trades broke a rule. Most common: {top.replace('_', ' ')}. Fix that one first.")
    rule_pnl = sum(t["pnl"] for t in ts if t["id"] in broken)
    if broken and rule_pnl < 0:
        tips.append(f"Trades that broke rules lost ${-rule_pnl:.0f} in total. Following your own rules would have saved that.")
    hours = {}
    for t in ts:
        hours.setdefault(t["opened"][11:13], []).append(t["pnl"])
    if len(hours) > 1:
        bad = min(hours, key=lambda h: sum(hours[h]))
        if sum(hours[bad]) < 0:
            tips.append(f"Your worst hour is {bad}:00 (${sum(hours[bad]):.0f}). Consider sitting it out.")
    if s["max_drawdown"] < 0:
        tips.append(f"Max drawdown is ${-s['max_drawdown']:.0f}. Make sure that fits your risk limits.")
    if not tips:
        tips.append("Clean discipline so far. Keep sample size growing before changing anything.")
    return {"score": round(100 * (1 - len(broken) / len(ts))), "violations": v, "tips": tips, "stats": s,
            "ai": ai_note(s, v, tips, r) if ai else None}


def ai_note(s, v, tips, r):
    key = os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        return None
    prompt = ("You are a blunt but supportive trading mentor. Using this data, tell the trader in under 150 words "
              "whether they broke their rules and the 3 most important things to improve.\n"
              + json.dumps({"rules": r, "stats": {k: s[k] for k in ("count", "win_rate", "profit_factor", "avg_win", "avg_loss", "total", "max_drawdown")},
                            "violations": v[:40], "tips": tips}))
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", method="POST",
        data=json.dumps({"model": os.environ.get("MENTOR_MODEL", "claude-sonnet-5-5"), "max_tokens": 500,
                         "messages": [{"role": "user", "content": prompt}]}).encode(),
        headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=30) as f:
            return json.load(f)["content"][0]["text"]
    except Exception as e:
        return f"(AI note unavailable: {e})"


def summary(ts, r):
    """Plain-text report you can paste into a chat with Claude for a free review."""
    if not ts:
        return "No trades yet. Add or import trades first."
    m = mentor(ts, r, ai=False)
    s, v = m["stats"], m["violations"]
    broken = {x["id"] for x in v}
    L = ["TRADE JOURNAL SUMMARY FOR MENTOR REVIEW", f"Generated: {datetime.now():%Y-%m-%d %H:%M}",
         f"Period: {ts[0]['opened'][:10]} to {ts[-1]['closed'][:10]}", "", "MY RULES"]
    L += [f"- {k}: {val:g}" for k, val in r.items()]
    L += ["", "STATS", f"- Trades: {s['count']} ({s['wins']}W / {s['losses']}L), win rate {s['win_rate']}%",
          f"- Profit factor: {s['profit_factor']}, avg win ${s['avg_win']}, avg loss ${s['avg_loss']}",
          f"- Total PNL: ${s['total']}, max drawdown ${s['max_drawdown']}",
          f"- Winning days: {s['day_wins']}W / {s['day_losses']}L ({s['day_win_pct']}%)",
          f"- Rule discipline score: {m['score']}% ({len(broken)} of {len(ts)} trades broke a rule)", "", "DAILY"]
    for d, p in sorted(s["daily"].items()):
        n = sum(t["closed"][:10] == d for t in ts)
        b = sum(x["date"] == d for x in v)
        L.append(f"- {d}: {n} trades, PNL ${p}, {b} rule breaks")
    L += ["", "RULE BREAKS"] + ([f"- {x['date']} {x['symbol']} (#{x['id']}) [{x['rule']}]: {x['msg']}" for x in v] or ["- None"])
    L += ["", "AUTO TIPS"] + [f"- {t}" for t in m["tips"]]
    L += ["", f"TRADES (last {min(len(ts), 150)}): id | opened | symbol side qty | entry -> exit | stop | pnl | broke rule | notes"]
    for t in ts[-150:]:
        L.append(f"{t['id']} | {t['opened'].replace('T', ' ')} | {t['symbol']} {t['side']} {t['qty']:g} | {t['entry']} -> {t['exit']} | "
                 f"{t['stop'] if t['stop'] else 'none'} | {t['pnl']} | {'YES' if t['id'] in broken else 'no'} | {(t['notes'] or '')[:80]}")
    L += ["", "QUESTIONS: Did I break my rules? What are the top 3 things to improve? Do my rules themselves need changing?"]
    return "\n".join(L)


@app.get("/api/summary")
def api_summary():
    return jsonify(text=summary(get_trades(), get_rules()))


@app.get("/")
def home():
    return send_from_directory("static", "index.html")


def filt(ts):
    side = request.args.get("side")
    return [t for t in ts if t["side"] == side] if side in ("long", "short") else ts


@app.get("/api/trades")
def api_trades():
    return jsonify(filt(get_trades()))


@app.delete("/api/trades")
def api_clear():
    with db() as c:
        c.execute("DELETE FROM trades")
    return jsonify(ok=True)


@app.post("/api/trades")
def api_add():
    try:
        with db() as c:
            insert(c, request.json)
    except (KeyError, ValueError, TypeError) as e:
        return jsonify(error=f"Invalid trade: {e}"), 400
    return jsonify(ok=True)


@app.delete("/api/trades/<int:i>")
def api_del(i):
    with db() as c:
        c.execute("DELETE FROM trades WHERE id=?", (i,))
    return jsonify(ok=True)


@app.post("/api/import")
def api_import():
    text = request.files["file"].read().decode("utf-8-sig")
    n = 0
    with db() as c:
        for row in csv.DictReader(io.StringIO(text)):
            row = {k.strip().lower(): v for k, v in row.items() if k}
            try:
                insert(c, row); n += 1
            except (KeyError, ValueError, TypeError):
                pass
    return jsonify(imported=n)


@app.post("/api/demo")
def api_demo():
    random.seed(7)
    now = datetime.now().replace(hour=9, minute=30, second=0, microsecond=0)
    with db() as c:
        for d in range(9, -1, -1):
            t0 = now - timedelta(days=d)
            if t0.weekday() > 4:
                continue
            for i in range(random.randint(2, 7)):
                o = t0 + timedelta(minutes=i * 40 + random.randint(0, 15))
                cl = o + timedelta(minutes=random.randint(3, 25))
                e = 18000 + random.randint(-50, 50)
                pts = random.choice([-40, -25, -15, 10, 20, 30, 45])
                stop = None if random.random() < .2 else e - 20
                insert(c, {"symbol": "NQ", "side": "long", "qty": random.choice([1, 1, 2, 6]), "entry": e,
                           "exit": e + pts, "stop": stop, "opened": o.isoformat(), "closed": cl.isoformat(),
                           "pnl": pts * 2 * 1, "notes": ""})
    return jsonify(ok=True)


@app.get("/api/stats")
def api_stats():
    return jsonify(stats(filt(get_trades())))


@app.route("/api/rules", methods=["GET", "POST"])
def api_rules():
    if request.method == "POST":
        with db() as c:
            for k, val in request.json.items():
                if k in RULES:
                    c.execute("INSERT OR REPLACE INTO rules VALUES(?,?)", (k, float(val)))
    return jsonify(get_rules())


@app.post("/api/mentor")
def api_mentor():
    return jsonify(mentor(get_trades(), get_rules()))


if __name__ == "__main__":
    app.run(debug=True)
