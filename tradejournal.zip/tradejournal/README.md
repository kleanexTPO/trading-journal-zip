# Tradejournal
```
pip install -r requirements.txt
python app.py        # open http://localhost:5000
```
- Click **Load demo data** on an empty page to try it.
- Set your rules under **My rules**, then run **Mentor**.
- Optional: `export ANTHROPIC_API_KEY=...` adds an AI-written note to the mentor review (`MENTOR_MODEL` overrides the model).
